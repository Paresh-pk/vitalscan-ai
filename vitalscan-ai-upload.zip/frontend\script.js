document.getElementById('healthForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    // --- 1. Gather & Compute Data ---

    // Body Metrics
    const weight = parseFloat(document.getElementById('weight').value);
    const heightCm = parseFloat(document.getElementById('height').value);
    const heightM = heightCm / 100;
    const bmi = +(weight / (heightM * heightM)).toFixed(1);

    // Inferences for ML (Mapping 20Q to required fields)
    const hasHighBP = document.getElementById('q1_bp_history').value === 'true';
    const estSystolicBP = hasHighBP ? 145 : 120;

    const hasDiabetes = document.getElementById('q2_diabetes_history').value === 'true';
    const estHbA1c = hasDiabetes ? 7.2 : 5.4;

    const estCholesterol = 190;

    const isInactive = document.getElementById('q9_inactive').value === 'true';
    const isLowSleep = document.getElementById('q10_low_sleep').value === 'true';

    const formData = {
        age: parseInt(document.getElementById('age').value),
        gender: parseInt(document.getElementById('gender').value),
        bmi: bmi,
        systolic_bp: estSystolicBP,
        hba1c: estHbA1c,
        cholesterol: estCholesterol,
        vigorous_activity: !isInactive,
        sleep_hours: isLowSleep ? 5.5 : 7.5,
        smoker_history: document.getElementById('smoker_history').value === 'true',

        q1_bp_history: document.getElementById('q1_bp_history').value === 'true',
        q2_diabetes_history: document.getElementById('q2_diabetes_history').value === 'true',
        q3_family_heart: document.getElementById('q3_family_heart').value === 'true',
        q4_dry_eyes: document.getElementById('q4_dry_eyes').value === 'true',
        q5_headaches: document.getElementById('q5_headaches').value === 'true',
        q6_neck_pain: document.getElementById('q6_neck_pain').value === 'true',
        q7_back_pain: document.getElementById('q7_back_pain').value === 'true',
        q8_sedentary: document.getElementById('q8_sedentary').value === 'true',
        q11_insomnia: document.getElementById('q11_insomnia').value === 'true',
        q12_overwhelmed: document.getElementById('q12_overwhelmed').value === 'true',
        q13_drained: document.getElementById('q13_drained').value === 'true',
        q14_anxious: document.getElementById('q14_anxious').value === 'true',
        q15_anhedonia: document.getElementById('q15_anhedonia').value === 'true',
        q16_phone_bedtime: document.getElementById('q16_phone_bedtime').value === 'true',
        q17_internet_anxiety: document.getElementById('q17_internet_anxiety').value === 'true',
        q18_breathlessness: document.getElementById('q18_breathlessness').value === 'true',
        q19_fatigue: document.getElementById('q19_fatigue').value === 'true',
        q20_diet: document.getElementById('q20_diet').value === 'true',

        daily_digital_hours: 8.0
    };

    // UI Feedback
    const submitBtn = document.querySelector('.cta-button');
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<span class="spinner"></span> Analyzing Bio-Data...';
    submitBtn.disabled = true;

    try {
        const response = await fetch('/api/v1/assess', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(formData)
        });

        if (!response.ok) {
            const err = await response.json();
            if (Array.isArray(err.detail)) {
                console.error("Validation Errors:", err.detail);
                const msg = err.detail.map(e => `Field '${e.loc[e.loc.length - 1]}': ${e.msg}`).join('\n');
                throw new Error("Missing/Invalid Fields:\n" + msg);
            }
            throw new Error(err.detail || 'Assessment failed');
        }

        const result = await response.json();
        renderResults(result);

    } catch (err) {
        alert("Error: " + err.message);
    } finally {
        submitBtn.innerHTML = originalText;
        submitBtn.disabled = false;
    }
});

function renderResults(data) {
    console.log("Rendering results:", data);

    // Hide Form, Show Results
    document.getElementById('assessment-form').classList.add('hidden');
    const resultSection = document.getElementById('results-view');
    resultSection.classList.remove('hidden');
    resultSection.classList.add('fade-in');

    // Calculate score
    const riskScore = data.risks.reduce((acc, r) => acc + r.probability, 0) / data.risks.length;
    console.log("Risk Score:", riskScore);

    // Update score display
    const scoreDisplay = document.getElementById('overall-score-display');
    if (scoreDisplay) {
        scoreDisplay.textContent = (riskScore * 10).toFixed(1);
    }

    const assessmentId = document.getElementById('assessment-id');
    if (assessmentId && data.assessment_id) {
        assessmentId.textContent = data.assessment_id.split('-')[0];

        // Store assessment context for chatbot
        if (window.chatbot) {
            window.chatbot.setAssessmentContext(data.assessment_id);
        }
    }

    // SVG Circle Animation
    const circle = document.querySelector('.progress-value');
    if (circle) {
        const radius = circle.r.baseVal.value;
        const circumference = radius * 2 * Math.PI;

        circle.style.strokeDasharray = `${circumference} ${circumference}`;
        circle.style.strokeDashoffset = circumference;

        const offset = circumference - (riskScore * circumference);

        setTimeout(() => {
            circle.style.strokeDashoffset = offset;
        }, 100);
    }

    // Risk Cards
    const grid = document.getElementById('risk-cards-container');
    if (grid) {
        grid.innerHTML = '';

        data.risks.forEach(risk => {
            const card = document.createElement('div');
            card.className = `risk-item ${risk.risk_level}`;

            card.innerHTML = `
                <div class="risk-header">
                    <h3>${risk.disease}</h3>
                    <span class="risk-level">${risk.risk_level}</span>
                </div>
                <p class="explanation"><strong>Primary Drivers:</strong> ${risk.contributing_factors.join(', ')}</p>
                <ul class="rec-list">
                    ${risk.prevention_steps.map(s => {
                const parts = s.split(':');
                if (parts.length > 1) {
                    return `<li>${s.replace(/\*\*/g, '<strong>').replace(/\*\*/g, '</strong>')}</li>`;
                }
                return `<li>${s}</li>`;
            }).join('')}
                </ul>
            `;
            grid.appendChild(card);
        });
    }
}

document.getElementById('reset-btn').addEventListener('click', () => {
    document.getElementById('results-view').classList.add('hidden');
    document.getElementById('assessment-form').classList.remove('hidden');
    document.getElementById('assessment-form').classList.add('fade-in');
});
